<h2>
    Creating a template
</h2>
<p>
    This screen is for adding a new translations template for a set of translatable strings.
</p>
<p>
    Your language files use this template to ensure they all reference the same strings.
</p>
<p>
    <a href="<?php echo esc_url(apply_filters('loco_external','https://localise.biz/wordpress/plugin/manual/templates'))?>" target="_blank">Full documentation</a>
</p>